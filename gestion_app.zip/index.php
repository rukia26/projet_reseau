<!DOCTYPE html>
<html lang="fr">
<head>
    <title>Tableau de Bord</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body class="container mt-5">

<h2 class="mb-4">Tableau de Bord</h2>

<ul class="list-group">
    <li class="list-group-item"><a href="employes.php">Gestion des Employés</a></li>
    <li class="list-group-item"><a href="clients.php">Gestion des Clients</a></li>
    <li class="list-group-item"><a href="documents.php">Gestion des Documents</a></li>
</ul>

</body>
</html>