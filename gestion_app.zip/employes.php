<?php
require 'config.php';
$stmt = $pdo->query("SELECT * FROM employes");
$employes = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <title>Gestion des Employés</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body class="container mt-5">

<h2>Gestion des Employés</h2>
<table class="table table-bordered">
    <thead>
        <tr><th>ID</th><th>Nom</th><th>Prénom</th><th>Poste</th><th>Email</th><th>Date Embauche</th><th>Actions</th></tr>
    </thead>
    <tbody>
        <?php foreach ($employes as $emp): ?>
        <tr>
            <td><?= $emp['id'] ?></td>
            <td><?= $emp['nom'] ?></td>
            <td><?= $emp['prenom'] ?></td>
            <td><?= $emp['poste'] ?></td>
            <td><?= $emp['email'] ?></td>
            <td><?= $emp['date_embauche'] ?></td>
            <td>
                <a href="edit_employe.php?id=<?= $emp['id'] ?>" class="btn btn-warning btn-sm">Modifier</a>
                <a href="delete_employe.php?id=<?= $emp['id'] ?>" class="btn btn-danger btn-sm">Supprimer</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<a href="add_employe.php" class="btn btn-primary">Ajouter un Employé</a>

</body>
</html>