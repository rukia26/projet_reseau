<?php
require 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sql = "INSERT INTO employes (nom, prenom, poste, email, date_embauche) VALUES (?, ?, ?, ?, ?)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$_POST['nom'], $_POST['prenom'], $_POST['poste'], $_POST['email'], $_POST['date_embauche']]);
    header("Location: employes.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <title>Ajouter un Employé</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body class="container mt-5">
<h2>Ajouter un Employé</h2>
<form method="POST">
    <input type="text" name="nom" class="form-control" placeholder="Nom" required>
    <input type="text" name="prenom" class="form-control" placeholder="Prénom" required>
    <input type="text" name="poste" class="form-control" placeholder="Poste">
    <input type="email" name="email" class="form-control" placeholder="Email">
    <input type="date" name="date_embauche" class="form-control">
    <button class="btn btn-success mt-3">Enregistrer</button>
</form>
</body>
</html>